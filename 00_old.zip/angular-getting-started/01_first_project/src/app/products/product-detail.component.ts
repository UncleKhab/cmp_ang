import { Component, OnDestroy, OnInit } from "@angular/core";
import { IProduct } from "./product";
import { ActivatedRoute, Router } from "@angular/router";
import { ProductService } from "./product.service";
import { Subscription } from "rxjs";
@Component({
  templateUrl: "./product-detail.component.html",
  styleUrls: ["./product-detail.component.css"],
})
export class ProductDetailComponent implements OnInit, OnDestroy {
  pageTitle: string = "Product Detail";
  product: IProduct | undefined;
  sub!: Subscription;
  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get("id"));
    this.pageTitle += `: ${id}`;
    this.sub = this.productService.getProducts().subscribe({
      next: (products) => {
        this.product = products.find((product) => product.productId === id);
      },
    });
  }
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }

  onBack(): void {
    this.router.navigate(["/products"]);
  }
}
