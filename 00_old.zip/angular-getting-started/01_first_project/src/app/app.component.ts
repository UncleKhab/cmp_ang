import { Component } from "@angular/core";

@Component({
  selector: "pm-root",
  templateUrl: "./app.component.html",
})
export class AppComponent {
  pageTitle: string = "Product Management";
}
